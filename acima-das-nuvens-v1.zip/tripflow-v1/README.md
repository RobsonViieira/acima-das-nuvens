# ✈ Acima das Nuvens — v1.0

> *"Só quem se arrisca merece viver o extraordinário"*

Planner de viagens com IA. HTML/CSS/JS puro — sem framework, sem dependências.

## Estrutura
```
acima-das-nuvens/
├── index.html   # Estrutura
├── style.css    # Estilos
├── app.js       # Toda a lógica
└── README.md
```

## Deploy no seu servidor AWS (EC2 + Nginx)

### 1. Clone ou copie os arquivos para o servidor
```bash
# No seu computador — zipar
zip -r acima-das-nuvens.zip index.html style.css app.js

# Enviar pro servidor
scp acima-das-nuvens.zip ubuntu@SEU_IP:/tmp/

# No servidor
ssh ubuntu@SEU_IP
cd /var/www/html
sudo unzip /tmp/acima-das-nuvens.zip
```

### 2. Configurar Nginx
```nginx
server {
    listen 80;
    server_name seudominio.com;
    root /var/www/html;
    index index.html;
    location / { try_files $uri $uri/ /index.html; }
}
```

### 3. (Opcional) HTTPS com Certbot
```bash
sudo certbot --nginx -d seudominio.com
```

## Notas
- Os dados ficam no localStorage do usuário
- A IA (aba "IA") usa a API do Claude direto do browser
- Para usar a IA em produção, adicione um proxy backend para proteger a API key
