// ═══════════════════════════════════════
//  ACIMA DAS NUVENS — app.js v1.0
// ═══════════════════════════════════════

const STORAGE_KEY = 'adn_v1';
const MESES = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
const CAT_COLORS = {
  '🍽️ Comida': '#fbbf24', '🚌 Transporte': '#60a5fa',
  '🏨 Hospedagem': '#c4b5fd', '🗺️ Passeio': '#34d399',
  '🛍️ Compras': '#f472b6', '📦 Outro': '#8b95b0'
};
const MALA_GROUPS = {
  '🧊 Frio': ['Casaco impermeável','Blusa térmica','Calça térmica','Gorro de lã','Luvas','Cachecol','Meias grossas (2x)'],
  '☀️ Quente': ['Camisetas (3x)','Shorts / calça leve','Tênis confortável','Sandália','Protetor solar FPS50+','Óculos de sol'],
  '💊 Saúde': ['Dipirona / analgésico','Antidiarreico','Curativo + antisséptico','Hidratante labial','Remédios pessoais'],
  '📋 Documentos': ['Passaporte / RG','Cópia dos documentos','Passagem impressa','Cartão de crédito','Seguro viagem'],
  '📱 Eletrônicos': ['Carregador','Adaptador universal','Power bank','Fone de ouvido','Chip / eSIM local']
};
const TAG_MAP = {
  transport:['tag-t','🚌 transporte'], tour:['tag-o','🗺️ passeio'],
  food:['tag-f','🍽️ comida'], hotel:['tag-h','🛏️ hotel'], free:['tag-l','✨ livre']
};

// ── STATE ──
let state = {
  setup: false, destino: '', emoji: '✈️',
  dataIda: '', dataVolta: '', orcamento: '', moeda: 'USD', meta: '',
  savedAmount: {}, mala: {}, gastos: [], iaHistory: []
};
let currentTab = 'dash';
let iaHistory = [];
let iaBusy = false;

function loadState() {
  try {
    const s = localStorage.getItem(STORAGE_KEY);
    if (s) state = { ...state, ...JSON.parse(s) };
  } catch(e) {}
}
function saveState() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch(e) {}
}
function resetApp() {
  if (!confirm('Recomeçar do zero? Todos os dados serão apagados.')) return;
  localStorage.removeItem(STORAGE_KEY);
  location.reload();
}

// ── HELPERS ──
function daysDiff(a, b) {
  if (!a || !b) return 0;
  return Math.max(0, Math.round((new Date(b) - new Date(a)) / 86400000));
}
function daysTo(d) {
  if (!d) return null;
  return Math.round((new Date(d) - new Date()) / 86400000);
}
function fmtDate(d) {
  if (!d) return '?';
  return new Date(d + 'T12:00').toLocaleDateString('pt-BR');
}
function getMonthBoxes() {
  if (!state.dataIda) return [];
  const boxes = [], start = new Date(), end = new Date(state.dataIda);
  let cur = new Date(start.getFullYear(), start.getMonth(), 1);
  while (cur <= end && boxes.length < 6) {
    const key = `${cur.getFullYear()}-${cur.getMonth()}`;
    boxes.push({
      key, label: MESES[cur.getMonth()],
      isCurrent: cur.getMonth() === start.getMonth() && cur.getFullYear() === start.getFullYear()
    });
    cur.setMonth(cur.getMonth() + 1);
  }
  return boxes;
}

// ═══════════════════════════════════════
//  SETUP WIZARD
// ═══════════════════════════════════════
const SETUP_STEPS = [
  { emoji: '🌍', q: 'Qual o destino da viagem?', key: 'destino', type: 'text', placeholder: 'Ex: Buenos Aires, Argentina', tip: 'Pode ser cidade, país ou região' },
  { emoji: '✨', q: 'Escolha um emoji para o destino', key: 'emoji', type: 'options', options: ['🇦🇷','🇧🇴','🇵🇪','🇨🇱','🇨🇴','🇺🇾','🇵🇾','🇪🇺','🇺🇸','🌏','🏔️','🏖️','🏙️','🌿'], tip: 'Vai aparecer no cabeçalho' },
  { emoji: '🛫', q: 'Data de ida?', key: 'dataIda', type: 'date', tip: 'Usamos para calcular a contagem regressiva' },
  { emoji: '🛬', q: 'Data de volta?', key: 'dataVolta', type: 'date', tip: 'Opcional — deixe em branco se não souber' },
  { emoji: '💵', q: 'Orçamento total para gastar na viagem?', key: 'orcamento', type: 'number', placeholder: 'Ex: 700', tip: 'Somente o número, sem símbolo de moeda' },
  { emoji: '💱', q: 'Moeda do orçamento?', key: 'moeda', type: 'options', options: ['USD','BRL','EUR','GBP','ARS','BOB','PEN','CLP'], tip: '' },
  { emoji: '🎯', q: 'Meta de economia antes da viagem?', key: 'meta', type: 'number', placeholder: 'Ex: 3000', optional: true, tip: 'Opcional — quanto você quer guardar antes de ir' }
];
let setupStep = 0;
let setupForm = {};

function renderSetupStep() {
  const s = SETUP_STEPS[setupStep];
  document.getElementById('sEmoji').textContent = s.emoji;
  document.getElementById('sQuestion').textContent = s.q;
  document.getElementById('setupFill').style.width = `${((setupStep) / SETUP_STEPS.length) * 100}%`;
  document.getElementById('setupTip').textContent = s.tip || '';
  document.getElementById('btnBack').style.visibility = setupStep > 0 ? 'visible' : 'hidden';
  document.getElementById('btnNext').textContent = setupStep === SETUP_STEPS.length - 1 ? '✓ Criar meu planner' : 'Próximo →';

  const area = document.getElementById('sInput');
  const cur = setupForm[s.key] ?? (s.type === 'options' ? (s.options[0]) : '');

  if (s.type === 'options') {
    area.innerHTML = `<div class="option-grid">${s.options.map(o =>
      `<button class="opt-btn ${cur === o ? 'sel' : ''}" onclick="selectOpt('${s.key}','${o}',this)">${o}</button>`
    ).join('')}</div>`;
    if (!setupForm[s.key]) setupForm[s.key] = s.options[0];
  } else {
    area.innerHTML = `<input class="setup-input" id="setupMainInput" type="${s.type}" value="${cur}" placeholder="${s.placeholder || ''}" ${s.type === 'date' ? '' : ''}>`;
    setTimeout(() => {
      const inp = document.getElementById('setupMainInput');
      if (inp) { inp.focus(); inp.addEventListener('keydown', e => { if (e.key === 'Enter') setupNext(); }); }
    }, 50);
  }
}

function selectOpt(key, val, btn) {
  setupForm[key] = val;
  btn.closest('.option-grid').querySelectorAll('.opt-btn').forEach(b => b.classList.remove('sel'));
  btn.classList.add('sel');
}

function setupNext() {
  const s = SETUP_STEPS[setupStep];
  if (s.type !== 'options') {
    const inp = document.getElementById('setupMainInput');
    if (inp) setupForm[s.key] = inp.value.trim();
  }
  if (!setupForm[s.key] && !s.optional) {
    const inp = document.getElementById('setupMainInput');
    if (inp) { inp.style.borderColor = '#ef4444'; inp.focus(); setTimeout(() => inp.style.borderColor = '', 1200); }
    return;
  }
  if (setupStep < SETUP_STEPS.length - 1) {
    setupStep++;
    const card = document.getElementById('setupCard');
    card.style.animation = 'none';
    requestAnimationFrame(() => { card.style.animation = 'cardIn .35s ease both'; });
    renderSetupStep();
  } else {
    Object.assign(state, setupForm, { setup: true });
    saveState();
    startApp();
  }
}

function setupBack() {
  if (setupStep > 0) { setupStep--; renderSetupStep(); }
}

// ═══════════════════════════════════════
//  APP
// ═══════════════════════════════════════
function startApp() {
  document.getElementById('setupScreen').classList.add('hidden');
  document.getElementById('appScreen').classList.remove('hidden');
  updateHeader();
  renderTab('dash');
}

function updateHeader() {
  const dLeft = daysTo(state.dataIda);
  document.getElementById('hdrCenter').textContent = state.destino ? `${state.emoji} ${state.destino}` : '';
  const badge = document.getElementById('hdrBadge');
  if (dLeft !== null && dLeft >= 0) {
    badge.textContent = dLeft === 0 ? '🔥 Hoje!' : `✈ ${dLeft} dias`;
    badge.style.display = 'flex';
  } else { badge.style.display = 'none'; }
}

function goTab(id) {
  currentTab = id;
  document.querySelectorAll('.tab').forEach(t => {
    t.classList.toggle('active', t.dataset.tab === id);
  });
  renderTab(id);
}

function renderTab(id) {
  const main = document.getElementById('main');
  main.innerHTML = '';
  if (id === 'dash') renderDash(main);
  else if (id === 'meta') renderMeta(main);
  else if (id === 'gastos') renderGastos(main);
  else if (id === 'mala') renderMala(main);
  else if (id === 'ia') renderIA(main);
}

// ── DASH ──
function renderDash(el) {
  const dLeft = daysTo(state.dataIda);
  const dias = daysDiff(state.dataIda, state.dataVolta);
  const meta = parseFloat(state.meta) || 0;
  const totalSaved = Object.values(state.savedAmount || {}).reduce((a, b) => a + (parseFloat(b) || 0), 0);
  const pct = meta > 0 ? Math.min((totalSaved / meta) * 100, 100) : 0;
  const orcamento = parseFloat(state.orcamento) || 0;
  const totalGasto = (state.gastos || []).reduce((a, g) => a + (parseFloat(g.valor) || 0), 0);
  const gastoPct = orcamento > 0 ? Math.min((totalGasto / orcamento) * 100, 100) : 0;

  el.innerHTML = `
    <div class="hero-card">
      <div class="hero-emoji">${state.emoji}</div>
      <div class="hero-dest">${state.destino || 'Minha Viagem'}</div>
      <div class="hero-dates">${state.dataIda ? fmtDate(state.dataIda) : '—'} → ${state.dataVolta ? fmtDate(state.dataVolta) : '—'}</div>
      <div class="hero-pills">
        <div class="hero-pill"><span class="hero-pill-val">${dLeft !== null && dLeft >= 0 ? (dLeft === 0 ? 'Hoje!' : dLeft) : '—'}</span><span class="hero-pill-lbl">${dLeft > 1 ? 'dias' : 'dia'}</span></div>
        ${dias > 0 ? `<div class="hero-pill"><span class="hero-pill-val">${dias}</span><span class="hero-pill-lbl">de viagem</span></div>` : ''}
        ${orcamento > 0 ? `<div class="hero-pill"><span class="hero-pill-val">${state.moeda} ${orcamento}</span><span class="hero-pill-lbl">orçamento</span></div>` : ''}
      </div>
    </div>

    ${meta > 0 ? `
    <div class="card" style="animation-delay:.05s">
      <div class="stat-row">
        <div><div class="stat-lbl">Guardado</div><div class="stat-val gold">${state.moeda} ${totalSaved.toFixed(0)}</div></div>
        <div style="text-align:right"><div class="stat-lbl">Meta</div><div class="stat-val muted">${state.moeda} ${meta.toFixed(0)}</div></div>
      </div>
      <div class="progress-wrap"><div class="progress-fill progress-blue" style="width:${pct}%"></div></div>
      <div class="prog-info"><span class="hi">${pct.toFixed(0)}% concluído</span><span>Faltam ${state.moeda} ${Math.max(meta - totalSaved, 0).toFixed(0)}</span></div>
    </div>` : ''}

    ${orcamento > 0 ? `
    <div class="card" style="animation-delay:.1s">
      <div class="stat-row">
        <div><div class="stat-lbl">Gasto na viagem</div><div class="stat-val green">${state.moeda} ${totalGasto.toFixed(0)}</div></div>
        <div style="text-align:right"><div class="stat-lbl">Orçamento</div><div class="stat-val muted">${state.moeda} ${orcamento}</div></div>
      </div>
      <div class="progress-wrap"><div class="progress-fill ${gastoPct > 85 ? 'progress-red' : 'progress-green'}" style="width:${gastoPct}%"></div></div>
      <div class="prog-info"><span class="hg">${gastoPct.toFixed(0)}% usado</span><span>Sobra ${state.moeda} ${Math.max(orcamento - totalGasto, 0).toFixed(0)}</span></div>
    </div>` : ''}

    <div class="card" style="animation-delay:.15s;text-align:center;padding:20px">
      <p style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:15px;color:#4a5268;line-height:1.7">
        "Só quem se arrisca merece viver o extraordinário"
      </p>
    </div>`;
}

// ── META ──
function renderMeta(el) {
  const meta = parseFloat(state.meta) || 0;
  const totalSaved = Object.values(state.savedAmount || {}).reduce((a, b) => a + (parseFloat(b) || 0), 0);
  const pct = meta > 0 ? Math.min((totalSaved / meta) * 100, 100) : 0;
  const boxes = getMonthBoxes();

  if (meta <= 0) {
    el.innerHTML = `<div class="card"><div class="empty-state">
      <div class="empty-icon">🎯</div>
      <div class="empty-h">Nenhuma meta configurada</div>
      <div class="empty-p">Reconfigure a viagem para adicionar uma meta de economia mensal</div>
      <button class="btn-primary" style="margin-top:16px;max-width:200px" onclick="resetApp()">Configurar →</button>
    </div></div>`;
    return;
  }

  el.innerHTML = `
    <div class="card">
      <div class="sec-title">💰 Progresso total</div>
      <div class="stat-row">
        <div><div class="stat-lbl">Guardado</div><div class="stat-val gold">${state.moeda} ${totalSaved.toFixed(0)}</div></div>
        <div style="text-align:right"><div class="stat-lbl">Meta</div><div class="stat-val muted">${state.moeda} ${meta.toFixed(0)}</div></div>
      </div>
      <div class="progress-wrap"><div class="progress-fill progress-blue" style="width:${pct}%"></div></div>
      <div class="prog-info"><span class="hi">${pct.toFixed(0)}%</span><span>Faltam ${state.moeda} ${Math.max(meta - totalSaved, 0).toFixed(0)}</span></div>
    </div>

    <div class="card">
      <div class="sec-title">📅 Por mês <span style="font-size:10px;letter-spacing:0;font-weight:400;color:#3d4d68">(toque para editar)</span></div>
      ${boxes.length === 0 ? `<p style="color:#3d4d68;font-size:13px;text-align:center;padding:16px">Configure a data de ida para ver os meses</p>` : ''}
      <div class="month-grid" id="monthGrid"></div>
    </div>`;

  const grid = document.getElementById('monthGrid');
  boxes.forEach(m => {
    const val = parseFloat(state.savedAmount?.[m.key]) || 0;
    const div = document.createElement('div');
    div.className = `month-box${m.isCurrent ? ' cur' : ''}${val > 0 && val >= (parseFloat(state.meta) / boxes.length * 0.8) ? ' done' : ''}`;
    div.innerHTML = `
      <span class="month-check">✓</span>
      <div class="month-name">${m.label}</div>
      <div class="month-val ${val === 0 ? 'empty' : ''}" id="mv-${m.key}">${val > 0 ? val.toFixed(0) : '—'}</div>
      <input class="month-input-field" id="mi-${m.key}" type="number" placeholder="0" value="${val || ''}">
      <div class="month-hint">toque p/ editar</div>`;
    div.addEventListener('click', () => {
      const vi = document.getElementById(`mi-${m.key}`);
      const vd = document.getElementById(`mv-${m.key}`);
      if (vi.style.display === 'block') return;
      vi.style.display = 'block'; vd.style.display = 'none';
      vi.focus(); vi.select();
      const done = () => {
        const v = parseFloat(vi.value) || 0;
        state.savedAmount = { ...state.savedAmount, [m.key]: v };
        saveState();
        vi.style.display = 'none'; vd.style.display = 'block';
        vd.textContent = v > 0 ? v.toFixed(0) : '—';
        vd.className = `month-val${v === 0 ? ' empty' : ''}`;
        // update progress
        const ts = Object.values(state.savedAmount).reduce((a, b) => a + (parseFloat(b) || 0), 0);
        const p = meta > 0 ? Math.min((ts / meta) * 100, 100) : 0;
        document.querySelector('.progress-fill.progress-blue').style.width = p + '%';
        document.querySelector('.hi').textContent = p.toFixed(0) + '%';
      };
      vi.addEventListener('blur', done, { once: true });
      vi.addEventListener('keydown', e => { if (e.key === 'Enter') vi.blur(); });
    });
    grid.appendChild(div);
  });
}

// ── GASTOS ──
function renderGastos(el) {
  const orcamento = parseFloat(state.orcamento) || 0;
  const gastos = state.gastos || [];
  const totalGasto = gastos.reduce((a, g) => a + (parseFloat(g.valor) || 0), 0);
  const gastoPct = orcamento > 0 ? Math.min((totalGasto / orcamento) * 100, 100) : 0;

  el.innerHTML = `
    <div class="card">
      <div class="sec-title">➕ Registrar gasto</div>
      <div class="form-group"><label class="form-label">Descrição</label>
        <input class="form-input" id="gDesc" placeholder="Ex: Jantar no mercado"></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Valor (${state.moeda})</label>
          <input class="form-input" id="gVal" type="number" placeholder="0.00"></div>
        <div class="form-group"><label class="form-label">Categoria</label>
          <select class="form-input" id="gCat">${Object.keys(CAT_COLORS).map(c => `<option>${c}</option>`).join('')}</select>
        </div>
      </div>
      <button class="btn-primary" onclick="addGasto()">Registrar +</button>
    </div>

    ${orcamento > 0 ? `
    <div class="card" style="animation-delay:.05s">
      <div class="stat-row">
        <div><div class="stat-lbl">Gasto total</div><div class="stat-val green">${state.moeda} ${totalGasto.toFixed(2)}</div></div>
        <div style="text-align:right"><div class="stat-lbl">Orçamento</div><div class="stat-val muted">${state.moeda} ${orcamento}</div></div>
      </div>
      <div class="progress-wrap"><div class="progress-fill ${gastoPct > 85 ? 'progress-red' : 'progress-green'}" style="width:${gastoPct}%"></div></div>
      <div class="prog-info"><span class="hg">${gastoPct.toFixed(0)}% usado</span><span>Sobra ${state.moeda} ${Math.max(orcamento - totalGasto, 0).toFixed(2)}</span></div>
    </div>` : ''}

    <div class="card" style="animation-delay:.1s">
      <div class="sec-title">🧾 Histórico</div>
      <div id="gastosLista">
        ${gastos.length === 0 ? `<div class="empty-state"><div class="empty-icon">🧾</div><div class="empty-h">Nenhum gasto ainda</div><div class="empty-p">Registre seus gastos durante a viagem</div></div>` : ''}
      </div>
    </div>`;

  const lista = document.getElementById('gastosLista');
  if (gastos.length > 0) {
    [...gastos].reverse().forEach(g => {
      const div = document.createElement('div');
      div.className = 'gasto-item';
      const color = CAT_COLORS[g.cat] || '#8b95b0';
      div.innerHTML = `
        <div class="gasto-icon" style="background:${color}18">${g.cat.split(' ')[0]}</div>
        <div class="gasto-info">
          <div class="gasto-desc">${g.desc}</div>
          <div class="gasto-meta">${g.cat.replace(/^\S+\s/,'')} · ${g.data}</div>
        </div>
        <div class="gasto-val">${state.moeda} ${parseFloat(g.valor).toFixed(2)}</div>
        <button class="gasto-del" onclick="delGasto(${g.id})">✕</button>`;
      lista.appendChild(div);
    });
  }

  document.getElementById('gDesc').addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('gVal').focus(); });
  document.getElementById('gVal').addEventListener('keydown', e => { if (e.key === 'Enter') addGasto(); });
}

function addGasto() {
  const desc = document.getElementById('gDesc').value.trim();
  const val = document.getElementById('gVal').value;
  const cat = document.getElementById('gCat').value;
  if (!desc || !val) return;
  state.gastos = [...(state.gastos || []), { id: Date.now(), desc, valor: parseFloat(val), cat, data: new Date().toLocaleDateString('pt-BR') }];
  saveState();
  renderTab('gastos');
}

function delGasto(id) {
  state.gastos = (state.gastos || []).filter(g => g.id !== id);
  saveState();
  renderTab('gastos');
}

// ── MALA ──
function renderMala(el) {
  const allItems = Object.values(MALA_GROUPS).flat();
  const packed = allItems.filter(i => {
    const k = Object.keys(MALA_GROUPS).find(g => MALA_GROUPS[g].includes(i));
    return !!state.mala?.[`${k}|${i}`];
  }).length;
  const malaPct = Math.round((packed / allItems.length) * 100);

  let html = `<div class="card">
    <div class="sec-title">🎒 Lista de Mala</div>
    <div style="display:flex;justify-content:space-between;margin-bottom:10px">
      <span style="font-size:12px;color:#7d8ba8">${packed} / ${allItems.length} itens</span>
      <span style="font-size:12px;font-weight:600;color:${malaPct === 100 ? '#22c55e' : '#93b4fd'}">${malaPct}%</span>
    </div>
    <div class="progress-wrap"><div class="progress-fill ${malaPct === 100 ? 'progress-green' : 'progress-blue'}" style="width:${malaPct}%"></div></div>
  </div>`;

  Object.entries(MALA_GROUPS).forEach(([group, items], gi) => {
    html += `<div class="card" style="animation-delay:${gi * .05}s">
      <div class="sec-title">${group}</div>
      <div id="mg-${gi}"></div>
    </div>`;
  });

  el.innerHTML = html;

  Object.entries(MALA_GROUPS).forEach(([group, items], gi) => {
    const container = document.getElementById(`mg-${gi}`);
    items.forEach(item => {
      const key = `${group}|${item}`;
      const checked = !!state.mala?.[key];
      const div = document.createElement('div');
      div.className = `mala-item${checked ? ' packed' : ''}`;
      div.innerHTML = `<div class="mala-chk">${checked ? '✓' : ''}</div><span>${item}</span>`;
      div.addEventListener('click', () => {
        state.mala = { ...state.mala, [key]: !state.mala?.[key] };
        saveState();
        div.classList.toggle('packed');
        div.querySelector('.mala-chk').textContent = state.mala[key] ? '✓' : '';
        div.querySelector('.mala-chk').style.background = state.mala[key] ? '#22c55e' : '';
        div.querySelector('.mala-chk').style.borderColor = state.mala[key] ? '#22c55e' : '';
        div.querySelector('.mala-chk').style.color = state.mala[key] ? '#fff' : '';
      });
      container.appendChild(div);
    });
  });
}

// ── IA ──
const IA_SYSTEM = `Você é o assistente de viagens do app "Acima das Nuvens". Seu slogan é "Só quem se arrisca merece viver o extraordinário".
Você é especialista em viagens pela América Latina. Converse com o viajante sobre o destino ${(function(){try{const s=JSON.parse(localStorage.getItem('adn_v1'));return s&&s.destino?s.destino:''}catch(e){return ''}})()} para entender o que ele quer fazer.
Quando tiver: destino + duração + orçamento → retorne APENAS JSON puro sem nenhum texto antes ou depois:
{"roteiro":{"destino":"Cidade, País","emoji":"🌍","datas":"Período","dias":7,"orcamento_total":"$700","dias_roteiro":[{"dia":1,"data":"10/07 · Seg","titulo":"Chegada","atividades":[{"horario":"15:00","titulo":"Nome","descricao":"Descrição rica e prática","tipo":"transport","custo":"~$10"}]}],"resumo_financeiro":[{"item":"Hospedagem","valor":"~$70"},{"item":"TOTAL","valor":"~$246"}],"dicas":["Dica 1","Dica 2","Dica 3"]}}
Tipos: transport, tour, food, hotel, free. Faça UMA pergunta por vez se faltar info. Com dados suficientes: APENAS JSON.`;

function renderIA(el) {
  el.innerHTML = `<div class="ia-wrap">
    <div class="ia-msgs" id="iaMsgs"></div>
    <div class="ia-input-row">
      <textarea id="iaInput" class="ia-textarea" placeholder="Pergunte sobre sua viagem ou peça um roteiro..." rows="1" onkeydown="iaKey(event)" oninput="iaResize(this)"></textarea>
      <button class="ia-send" id="iaSend" onclick="iaSend()">➤</button>
    </div>
  </div>`;

  const msgs = document.getElementById('iaMsgs');

  if (iaHistory.length === 0) {
    addIaMsg('ai', `Olá! Sou seu assistente de viagem ✈️<br><br>Você está planejando ir para <strong>${state.destino || 'um destino incrível'}</strong>. Posso montar um roteiro completo, responder dúvidas ou dar dicas.<br><br>Me conta: quanto tempo você tem e o que mais te interessa fazer? 🌍`);
  } else {
    iaHistory.forEach(m => addIaMsg(m.role === 'user' ? 'user' : 'ai', m.content.replace(/\n/g,'<br>')));
  }
}

function addIaMsg(role, html) {
  const c = document.getElementById('iaMsgs');
  if (!c) return;
  const w = document.createElement('div');
  w.className = `ia-msg ${role === 'user' ? 'u' : 'ai'}`;
  const av = document.createElement('div'); av.className = 'ia-av';
  av.textContent = role === 'user' ? 'EU' : '✦';
  const b = document.createElement('div'); b.className = 'ia-bbl';
  b.innerHTML = html;
  w.appendChild(av); w.appendChild(b);
  c.appendChild(w);
  c.scrollTop = c.scrollHeight;
}

function iaResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 90) + 'px';
}
function iaKey(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); iaSend(); } }

async function iaSend() {
  if (iaBusy) return;
  const inp = document.getElementById('iaInput');
  const txt = inp.value.trim(); if (!txt) return;
  inp.value = ''; inp.style.height = 'auto';
  document.getElementById('iaSend').disabled = true;
  iaBusy = true;

  addIaMsg('user', txt.replace(/\n/g,'<br>'));
  iaHistory.push({ role: 'user', content: txt });

  // typing
  const c = document.getElementById('iaMsgs');
  const tw = document.createElement('div'); tw.className = 'ia-msg ai'; tw.id = 'iaTyping';
  const tav = document.createElement('div'); tav.className = 'ia-av'; tav.textContent = '✦';
  tav.style.cssText = 'background:linear-gradient(135deg,#4169e1,#6c3aed);color:#fff;font-size:13px;box-shadow:0 0 12px rgba(65,105,225,.4)';
  const tb = document.createElement('div'); tb.className = 'ia-typing';
  tb.innerHTML = '<div class="ia-dot"></div><div class="ia-dot"></div><div class="ia-dot"></div>';
  tw.appendChild(tav); tw.appendChild(tb); c.appendChild(tw); c.scrollTop = c.scrollHeight;

  const sysWithDest = IA_SYSTEM.replace('${(function(){try{const s=JSON.parse(localStorage.getItem(\'adn_v1\'));return s&&s.destino?s.destino:\'\'}catch(e){return \'\'}})()} ', state.destino || '');

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 4096,
        system: sysWithDest,
        messages: iaHistory
      })
    });
    const data = await res.json();
    const reply = data.content?.[0]?.text || '';
    document.getElementById('iaTyping')?.remove();
    iaHistory.push({ role: 'assistant', content: reply });

    let parsed = null;
    try { const m = reply.match(/\{[\s\S]*\}/); if (m) parsed = JSON.parse(m[0]); } catch(e) {}

    if (parsed?.roteiro) {
      addIaMsg('ai', `Prontinho! 🎉 Aqui está seu roteiro para <strong>${parsed.roteiro.destino}</strong>:`);
      renderRoteiroCard(parsed.roteiro);
    } else {
      addIaMsg('ai', reply.replace(/\n/g,'<br>'));
    }
  } catch(e) {
    document.getElementById('iaTyping')?.remove();
    addIaMsg('ai', 'Erro de conexão. Tente novamente! 🔄');
  }

  document.getElementById('iaSend').disabled = false;
  iaBusy = false;
}

function renderRoteiroCard(r) {
  const c = document.getElementById('iaMsgs');
  const wrap = document.createElement('div');
  wrap.style.cssText = 'animation:fadeUp .4s ease both;max-width:100%';

  const days = r.dias_roteiro.map((d, i) => `
    <div class="dia-block" style="animation-delay:${i*.06}s">
      <div class="dia-header">
        <span class="dia-badge">dia ${d.dia}</span>
        <span class="dia-title">${d.titulo}</span>
        <span class="dia-date">${d.data}</span>
      </div>
      ${d.atividades.map(a => {
        const [cls, lbl] = TAG_MAP[a.tipo] || ['tag-l','✨ livre'];
        return `<div class="ativ-row">
          <div class="ativ-time">${a.horario}</div>
          <div class="ativ-body">
            <div class="ativ-title">${a.titulo}<span class="ativ-tag ${cls}">${lbl}</span></div>
            <div class="ativ-desc">${a.descricao}</div>
          </div>
          ${a.custo ? `<div class="ativ-cost">${a.custo}</div>` : ''}
        </div>`;
      }).join('')}
    </div>`).join('');

  wrap.innerHTML = `
    <div class="roteiro-hero" style="margin:0 0 14px">
      <div class="roteiro-dest">${r.emoji} ${r.destino}</div>
      <div class="roteiro-dates">${r.datas}</div>
      <div class="roteiro-pills">
        <div class="roteiro-pill"><span class="roteiro-pill-v">${r.dias}</span><span class="roteiro-pill-l">dias</span></div>
        <div class="roteiro-pill"><span class="roteiro-pill-v">${r.orcamento_total}</span><span class="roteiro-pill-l">orçamento</span></div>
      </div>
    </div>
    ${days}
    <div class="card" style="margin:0 0 12px">
      <div class="sec-title">💵 Resumo Financeiro</div>
      ${r.resumo_financeiro.map(b => `<div class="budget-row"><span>${b.item}</span><span>${b.valor}</span></div>`).join('')}
    </div>
    ${r.dicas?.length ? `<div class="tips-block" style="margin-bottom:12px"><div class="tips-title">✦ dicas</div>${r.dicas.map(d=>`<div class="tip-item">${d}</div>`).join('')}</div>` : ''}`;

  c.appendChild(wrap);
  c.scrollTop = c.scrollHeight;
}

// ═══════════════════════════════════════
//  INIT
// ═══════════════════════════════════════
loadState();
if (state.setup) {
  startApp();
} else {
  setupStep = 0;
  setupForm = {};
  renderSetupStep();
}
