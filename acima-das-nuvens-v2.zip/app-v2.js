// ═══════════════════════════════════════
//  ACIMA DAS NUVENS — v2.0 (com Supabase)
// ═══════════════════════════════════════

const SUPABASE_URL = 'https://vlhpnqvtgzeiaxinyuqc.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZsaHBucXZ0Z3plaWF4aW55dXFjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM1MjI5MjIsImV4cCI6MjA4OTA5ODkyMn0.aPy01YBoF4NxZ68SqT3jr9v2rSBHrBepEDaOPHAtSKE';

// ── SUPABASE CLIENT ──
const supa = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const MESES = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
const CAT_COLORS = {
  '🍽️ Comida':'#fbbf24','🚌 Transporte':'#60a5fa',
  '🏨 Hospedagem':'#c4b5fd','🗺️ Passeio':'#34d399',
  '🛍️ Compras':'#f472b6','📦 Outro':'#8b95b0'
};
const MALA_GROUPS = {
  '🧊 Frio':['Casaco impermeável','Blusa térmica','Calça térmica','Gorro de lã','Luvas','Cachecol','Meias grossas (2x)'],
  '☀️ Quente':['Camisetas (3x)','Shorts / calça leve','Tênis confortável','Sandália','Protetor solar FPS50+','Óculos de sol'],
  '💊 Saúde':['Dipirona / analgésico','Antidiarreico','Curativo + antisséptico','Hidratante labial','Remédios pessoais'],
  '📋 Documentos':['Passaporte / RG','Cópia dos documentos','Passagem impressa','Cartão de crédito','Seguro viagem'],
  '📱 Eletrônicos':['Carregador','Adaptador universal','Power bank','Fone de ouvido','Chip / eSIM local']
};
const TAG_MAP = {
  transport:['tag-t','🚌 transporte'],tour:['tag-o','🗺️ passeio'],
  food:['tag-f','🍽️ comida'],hotel:['tag-h','🛏️ hotel'],free:['tag-l','✨ livre']
};

// ── STATE ──
let currentUser = null;
let currentViagem = null;
let allViagens = [];
let currentTab = 'dash';
let iaHistory = [];
let iaBusy = false;

// ═══════════════════════════════════════
//  AUTH
// ═══════════════════════════════════════
async function initAuth() {
  const { data: { session } } = await supa.auth.getSession();
  if (session) {
    currentUser = session.user;
    await loadViagens();
  } else {
    showAuthScreen();
  }

  supa.auth.onAuthStateChange(async (event, session) => {
    if (event === 'SIGNED_IN') {
      currentUser = session.user;
      await loadViagens();
    } else if (event === 'SIGNED_OUT') {
      currentUser = null;
      currentViagem = null;
      showAuthScreen();
    }
  });
}

function showAuthScreen() {
  document.getElementById('authScreen').classList.remove('hidden');
  document.getElementById('setupScreen').classList.add('hidden');
  document.getElementById('appScreen').classList.add('hidden');
  document.getElementById('viagensScreen').classList.add('hidden');
}

async function signUp() {
  const email = document.getElementById('authEmail').value.trim();
  const password = document.getElementById('authPassword').value;
  const name = document.getElementById('authName').value.trim();
  if (!email || !password || !name) return showAuthError('Preencha todos os campos');
  
  setAuthLoading(true);
  const { error } = await supa.auth.signUp({ 
    email, password,
    options: { data: { name } }
  });
  setAuthLoading(false);
  if (error) return showAuthError(error.message);
  showAuthError('Verifique seu email para confirmar a conta!', true);
}

async function signIn() {
  const email = document.getElementById('authEmail').value.trim();
  const password = document.getElementById('authPassword').value;
  if (!email || !password) return showAuthError('Preencha email e senha');
  
  setAuthLoading(true);
  const { error } = await supa.auth.signInWithPassword({ email, password });
  setAuthLoading(false);
  if (error) return showAuthError('Email ou senha incorretos');
}

async function signOut() {
  await supa.auth.signOut();
}

function showAuthError(msg, success = false) {
  const el = document.getElementById('authError');
  el.textContent = msg;
  el.style.color = success ? '#22c55e' : '#ef4444';
  el.style.display = 'block';
}
function setAuthLoading(v) {
  document.getElementById('btnSignIn').disabled = v;
  document.getElementById('btnSignUp').disabled = v;
}
function toggleAuthMode() {
  const nameGroup = document.getElementById('nameGroup');
  const isLogin = nameGroup.style.display === 'none';
  nameGroup.style.display = isLogin ? 'block' : 'none';
  document.getElementById('authToggleText').textContent = isLogin 
    ? 'Já tem conta? Entrar' : 'Não tem conta? Cadastrar';
  document.getElementById('authTitle').textContent = isLogin ? 'Criar conta' : 'Entrar';
  document.getElementById('authError').style.display = 'none';
}

// ═══════════════════════════════════════
//  VIAGENS
// ═══════════════════════════════════════
async function loadViagens() {
  const { data } = await supa.from('viagens').select('*').order('created_at', { ascending: false });
  allViagens = data || [];
  
  if (allViagens.length === 0) {
    showSetup();
  } else if (!currentViagem) {
    currentViagem = allViagens[0];
    showApp();
  } else {
    showApp();
  }
}

function showViagensScreen() {
  document.getElementById('authScreen').classList.add('hidden');
  document.getElementById('setupScreen').classList.add('hidden');
  document.getElementById('appScreen').classList.add('hidden');
  document.getElementById('viagensScreen').classList.remove('hidden');
  renderViagensScreen();
}

function renderViagensScreen() {
  const el = document.getElementById('viagensList');
  el.innerHTML = allViagens.map(v => `
    <div class="viagem-card ${currentViagem?.id === v.id ? 'ativa' : ''}" onclick="selectViagem('${v.id}')">
      <div class="viagem-emoji">${v.emoji}</div>
      <div class="viagem-info">
        <div class="viagem-nome">${v.destino}</div>
        <div class="viagem-datas">${v.data_ida ? fmtDate(v.data_ida) : '—'} → ${v.data_volta ? fmtDate(v.data_volta) : '—'}</div>
      </div>
      ${currentViagem?.id === v.id ? '<div class="viagem-ativa-badge">ativa</div>' : ''}
      <button class="viagem-del" onclick="event.stopPropagation();deleteViagem('${v.id}')">✕</button>
    </div>`).join('');
}

function selectViagem(id) {
  currentViagem = allViagens.find(v => v.id === id);
  iaHistory = [];
  showApp();
}

async function deleteViagem(id) {
  if (!confirm('Apagar esta viagem e todos os dados?')) return;
  await supa.from('viagens').delete().eq('id', id);
  allViagens = allViagens.filter(v => v.id !== id);
  if (currentViagem?.id === id) currentViagem = allViagens[0] || null;
  if (!currentViagem) showSetup();
  else { renderViagensScreen(); }
}

function showApp() {
  document.getElementById('authScreen').classList.add('hidden');
  document.getElementById('setupScreen').classList.add('hidden');
  document.getElementById('viagensScreen').classList.add('hidden');
  document.getElementById('appScreen').classList.remove('hidden');
  updateHeader();
  goTab('dash');
}

function showSetup() {
  document.getElementById('authScreen').classList.add('hidden');
  document.getElementById('appScreen').classList.add('hidden');
  document.getElementById('viagensScreen').classList.add('hidden');
  document.getElementById('setupScreen').classList.remove('hidden');
  setupStep = 0; setupForm = {};
  renderSetupStep();
}

// ═══════════════════════════════════════
//  SETUP WIZARD
// ═══════════════════════════════════════
const SETUP_STEPS = [
  { emoji:'🌍', q:'Qual o destino da viagem?', key:'destino', type:'text', placeholder:'Ex: Buenos Aires, Argentina', tip:'Pode ser cidade, país ou região' },
  { emoji:'✨', q:'Escolha um emoji para o destino', key:'emoji', type:'options', options:['🇦🇷','🇧🇴','🇵🇪','🇨🇱','🇨🇴','🇺🇾','🇵🇾','🇪🇺','🇺🇸','🌏','🏔️','🏖️','🏙️','🌿'], tip:'Vai aparecer no cabeçalho' },
  { emoji:'🛫', q:'Data de ida?', key:'data_ida', type:'date', tip:'Usamos para calcular a contagem regressiva' },
  { emoji:'🛬', q:'Data de volta?', key:'data_volta', type:'date', optional:true, tip:'Opcional' },
  { emoji:'💵', q:'Orçamento total para gastar na viagem?', key:'orcamento', type:'number', placeholder:'Ex: 700', tip:'Só o número, sem símbolo' },
  { emoji:'💱', q:'Moeda do orçamento?', key:'moeda', type:'options', options:['USD','BRL','EUR','GBP','ARS','BOB','PEN','CLP'], tip:'' },
  { emoji:'🎯', q:'Meta de economia antes da viagem?', key:'meta', type:'number', placeholder:'Ex: 3000', optional:true, tip:'Opcional — quanto quer guardar antes de ir' }
];
let setupStep = 0, setupForm = {};

function renderSetupStep() {
  const s = SETUP_STEPS[setupStep];
  document.getElementById('sEmoji').textContent = s.emoji;
  document.getElementById('sQuestion').textContent = s.q;
  document.getElementById('setupFill').style.width = `${(setupStep / SETUP_STEPS.length) * 100}%`;
  document.getElementById('setupTip').textContent = s.tip || '';
  document.getElementById('btnBack').style.visibility = setupStep > 0 ? 'visible' : 'hidden';
  document.getElementById('btnNext').textContent = setupStep === SETUP_STEPS.length - 1 ? '✓ Criar viagem' : 'Próximo →';
  const cur = setupForm[s.key] ?? (s.type === 'options' ? s.options[0] : '');
  const area = document.getElementById('sInput');
  if (s.type === 'options') {
    area.innerHTML = `<div class="option-grid">${s.options.map(o =>
      `<button class="opt-btn ${cur===o?'sel':''}" onclick="selectOpt('${s.key}','${o}',this)">${o}</button>`
    ).join('')}</div>`;
    if (!setupForm[s.key]) setupForm[s.key] = s.options[0];
  } else {
    area.innerHTML = `<input class="setup-input" id="setupMainInput" type="${s.type}" value="${cur}" placeholder="${s.placeholder||''}">`;
    setTimeout(() => {
      const inp = document.getElementById('setupMainInput');
      if (inp) { inp.focus(); inp.addEventListener('keydown', e => { if(e.key==='Enter') setupNext(); }); }
    }, 50);
  }
}

function selectOpt(key, val, btn) {
  setupForm[key] = val;
  btn.closest('.option-grid').querySelectorAll('.opt-btn').forEach(b => b.classList.remove('sel'));
  btn.classList.add('sel');
}

async function setupNext() {
  const s = SETUP_STEPS[setupStep];
  if (s.type !== 'options') {
    const inp = document.getElementById('setupMainInput');
    if (inp) setupForm[s.key] = inp.value.trim();
  }
  if (!setupForm[s.key] && !s.optional) {
    const inp = document.getElementById('setupMainInput');
    if (inp) { inp.style.borderColor='#ef4444'; inp.focus(); setTimeout(()=>inp.style.borderColor='',1200); }
    return;
  }
  if (setupStep < SETUP_STEPS.length - 1) {
    setupStep++;
    const card = document.getElementById('setupCard');
    card.style.animation = 'none';
    requestAnimationFrame(() => { card.style.animation = 'cardIn .35s ease both'; });
    renderSetupStep();
  } else {
    // Save to Supabase
    const btnNext = document.getElementById('btnNext');
    btnNext.textContent = 'Salvando...';
    btnNext.disabled = true;
    const { data, error } = await supa.from('viagens').insert([{
      user_id: currentUser.id,
      destino: setupForm.destino,
      emoji: setupForm.emoji || '✈️',
      data_ida: setupForm.data_ida || null,
      data_volta: setupForm.data_volta || null,
      orcamento: parseFloat(setupForm.orcamento) || 0,
      moeda: setupForm.moeda || 'USD',
      meta: parseFloat(setupForm.meta) || 0,
    }]).select().single();
    if (error) { btnNext.textContent='Erro, tente novamente'; btnNext.disabled=false; return; }
    currentViagem = data;
    allViagens.unshift(data);
    iaHistory = [];
    showApp();
  }
}

function setupBack() {
  if (setupStep > 0) { setupStep--; renderSetupStep(); }
}

// ═══════════════════════════════════════
//  APP
// ═══════════════════════════════════════
function updateHeader() {
  if (!currentViagem) return;
  const dLeft = daysTo(currentViagem.data_ida);
  document.getElementById('hdrCenter').textContent = `${currentViagem.emoji} ${currentViagem.destino}`;
  const badge = document.getElementById('hdrBadge');
  if (dLeft !== null && dLeft >= 0) {
    badge.textContent = dLeft === 0 ? '🔥 Hoje!' : `✈ ${dLeft} dias`;
    badge.style.display = 'flex';
  } else { badge.style.display = 'none'; }
}

function goTab(id) {
  currentTab = id;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === id));
  renderTab(id);
}

function renderTab(id) {
  const main = document.getElementById('main');
  main.innerHTML = '';
  if (id==='dash') renderDash(main);
  else if (id==='meta') renderMeta(main);
  else if (id==='gastos') renderGastos(main);
  else if (id==='mala') renderMala(main);
  else if (id==='ia') renderIA(main);
}

// ── HELPERS ──
function daysDiff(a,b){if(!a||!b)return 0;return Math.max(0,Math.round((new Date(b)-new Date(a))/86400000));}
function daysTo(d){if(!d)return null;return Math.round((new Date(d)-new Date())/86400000);}
function fmtDate(d){if(!d)return '?';return new Date(d+'T12:00').toLocaleDateString('pt-BR');}
function getMonthBoxes(){
  if(!currentViagem?.data_ida)return[];
  const boxes=[],start=new Date(),end=new Date(currentViagem.data_ida);
  let cur=new Date(start.getFullYear(),start.getMonth(),1);
  while(cur<=end&&boxes.length<6){
    const key=`${cur.getFullYear()}-${cur.getMonth()}`;
    boxes.push({key,label:MESES[cur.getMonth()],isCurrent:cur.getMonth()===start.getMonth()&&cur.getFullYear()===start.getFullYear()});
    cur.setMonth(cur.getMonth()+1);
  }
  return boxes;
}

// ── DASH ──
function renderDash(el) {
  if (!currentViagem) return;
  const v = currentViagem;
  const dLeft = daysTo(v.data_ida);
  const dias = daysDiff(v.data_ida, v.data_volta);
  el.innerHTML = `
    <div class="hero-card">
      <div class="hero-emoji">${v.emoji}</div>
      <div class="hero-dest">${v.destino}</div>
      <div class="hero-dates">${v.data_ida?fmtDate(v.data_ida):'—'} → ${v.data_volta?fmtDate(v.data_volta):'—'}</div>
      <div class="hero-pills">
        <div class="hero-pill"><span class="hero-pill-val">${dLeft!==null&&dLeft>=0?(dLeft===0?'Hoje!':dLeft):'—'}</span><span class="hero-pill-lbl">dias</span></div>
        ${dias>0?`<div class="hero-pill"><span class="hero-pill-val">${dias}</span><span class="hero-pill-lbl">de viagem</span></div>`:''}
        ${v.orcamento>0?`<div class="hero-pill"><span class="hero-pill-val">${v.moeda} ${v.orcamento}</span><span class="hero-pill-lbl">orçamento</span></div>`:''}
      </div>
    </div>
    <div id="dashMeta"></div>
    <div id="dashGasto"></div>
    <div class="card" style="animation-delay:.15s;text-align:center;padding:20px">
      <p style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:15px;color:#3d4d68;line-height:1.7">"Só quem se arrisca merece viver o extraordinário"</p>
    </div>`;
  loadDashStats();
}

async function loadDashStats() {
  if (!currentViagem) return;
  const v = currentViagem;
  
  // Economia
  const { data: eco } = await supa.from('economia').select('valor').eq('viagem_id', v.id);
  const totalSaved = (eco||[]).reduce((a,b) => a+(parseFloat(b.valor)||0), 0);
  const meta = parseFloat(v.meta)||0;
  const pct = meta>0 ? Math.min((totalSaved/meta)*100,100) : 0;
  
  if (meta>0) {
    document.getElementById('dashMeta').innerHTML = `
      <div class="card" style="animation-delay:.05s">
        <div class="stat-row">
          <div><div class="stat-lbl">Guardado</div><div class="stat-val gold">${v.moeda} ${totalSaved.toFixed(0)}</div></div>
          <div style="text-align:right"><div class="stat-lbl">Meta</div><div class="stat-val muted">${v.moeda} ${meta.toFixed(0)}</div></div>
        </div>
        <div class="progress-wrap"><div class="progress-fill progress-blue" style="width:${pct}%"></div></div>
        <div class="prog-info"><span class="hi">${pct.toFixed(0)}%</span><span>Faltam ${v.moeda} ${Math.max(meta-totalSaved,0).toFixed(0)}</span></div>
      </div>`;
  }
  
  // Gastos
  const { data: gastos } = await supa.from('gastos').select('valor').eq('viagem_id', v.id);
  const totalGasto = (gastos||[]).reduce((a,b) => a+(parseFloat(b.valor)||0), 0);
  const orcamento = parseFloat(v.orcamento)||0;
  const gastoPct = orcamento>0 ? Math.min((totalGasto/orcamento)*100,100) : 0;
  
  if (orcamento>0) {
    document.getElementById('dashGasto').innerHTML = `
      <div class="card" style="animation-delay:.1s">
        <div class="stat-row">
          <div><div class="stat-lbl">Gasto na viagem</div><div class="stat-val green">${v.moeda} ${totalGasto.toFixed(0)}</div></div>
          <div style="text-align:right"><div class="stat-lbl">Orçamento</div><div class="stat-val muted">${v.moeda} ${orcamento}</div></div>
        </div>
        <div class="progress-wrap"><div class="progress-fill ${gastoPct>85?'progress-red':'progress-green'}" style="width:${gastoPct}%"></div></div>
        <div class="prog-info"><span class="hg">${gastoPct.toFixed(0)}%</span><span>Sobra ${v.moeda} ${Math.max(orcamento-totalGasto,0).toFixed(0)}</span></div>
      </div>`;
  }
}

// ── META ──
async function renderMeta(el) {
  const v = currentViagem;
  const meta = parseFloat(v.meta)||0;
  if (meta<=0) {
    el.innerHTML=`<div class="card"><div class="empty-state"><div class="empty-icon">🎯</div><div class="empty-h">Sem meta configurada</div></div></div>`;
    return;
  }
  const { data: eco } = await supa.from('economia').select('*').eq('viagem_id', v.id);
  const ecoMap = {};
  (eco||[]).forEach(e => ecoMap[e.mes_key] = { id: e.id, valor: e.valor });
  const totalSaved = Object.values(ecoMap).reduce((a,b) => a+(parseFloat(b.valor)||0), 0);
  const pct = Math.min((totalSaved/meta)*100,100);
  const boxes = getMonthBoxes();

  el.innerHTML = `
    <div class="card">
      <div class="sec-title">💰 Progresso total</div>
      <div class="stat-row">
        <div><div class="stat-lbl">Guardado</div><div class="stat-val gold">${v.moeda} ${totalSaved.toFixed(0)}</div></div>
        <div style="text-align:right"><div class="stat-lbl">Meta</div><div class="stat-val muted">${v.moeda} ${meta.toFixed(0)}</div></div>
      </div>
      <div class="progress-wrap"><div class="progress-fill progress-blue" style="width:${pct}%"></div></div>
      <div class="prog-info"><span class="hi">${pct.toFixed(0)}%</span><span>Faltam ${v.moeda} ${Math.max(meta-totalSaved,0).toFixed(0)}</span></div>
    </div>
    <div class="card"><div class="sec-title">📅 Por mês</div><div class="month-grid" id="monthGrid"></div></div>`;

  const grid = document.getElementById('monthGrid');
  boxes.forEach(m => {
    const eco_item = ecoMap[m.key];
    const val = parseFloat(eco_item?.valor)||0;
    const div = document.createElement('div');
    div.className = `month-box${m.isCurrent?' cur':''}${val>0?' done':''}`;
    div.innerHTML = `<span class="month-check">✓</span>
      <div class="month-name">${m.label}</div>
      <div class="month-val ${val===0?'empty':''}" id="mv-${m.key}">${val>0?val.toFixed(0):'—'}</div>
      <input class="month-input-field" id="mi-${m.key}" type="number" placeholder="0" value="${val||''}">
      <div class="month-hint">toque p/ editar</div>`;
    div.addEventListener('click', () => {
      const vi=document.getElementById(`mi-${m.key}`),vd=document.getElementById(`mv-${m.key}`);
      if(vi.style.display==='block')return;
      vi.style.display='block';vd.style.display='none';vi.focus();vi.select();
      const done=async()=>{
        const newVal=parseFloat(vi.value)||0;
        if(eco_item){
          await supa.from('economia').update({valor:newVal}).eq('id',eco_item.id);
          eco_item.valor=newVal;
        } else {
          const {data}=await supa.from('economia').insert([{viagem_id:v.id,user_id:currentUser.id,mes_key:m.key,valor:newVal}]).select().single();
          if(data)ecoMap[m.key]={id:data.id,valor:newVal};
        }
        vi.style.display='none';vd.style.display='block';
        vd.textContent=newVal>0?newVal.toFixed(0):'—';
        vd.className=`month-val${newVal===0?' empty':''}`;
      };
      vi.addEventListener('blur',done,{once:true});
      vi.addEventListener('keydown',e=>{if(e.key==='Enter')vi.blur();});
    });
    grid.appendChild(div);
  });
}

// ── GASTOS ──
async function renderGastos(el) {
  const v = currentViagem;
  const { data: gastos } = await supa.from('gastos').select('*').eq('viagem_id', v.id).order('created_at', {ascending:false});
  const lista = gastos||[];
  const totalGasto = lista.reduce((a,g)=>a+(parseFloat(g.valor)||0),0);
  const orcamento = parseFloat(v.orcamento)||0;
  const gastoPct = orcamento>0?Math.min((totalGasto/orcamento)*100,100):0;

  el.innerHTML = `
    <div class="card">
      <div class="sec-title">➕ Registrar gasto</div>
      <div class="form-group"><label class="form-label">Descrição</label>
        <input class="form-input" id="gDesc" placeholder="Ex: Jantar no mercado"></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Valor (${v.moeda})</label>
          <input class="form-input" id="gVal" type="number" placeholder="0.00"></div>
        <div class="form-group"><label class="form-label">Categoria</label>
          <select class="form-input" id="gCat">${Object.keys(CAT_COLORS).map(c=>`<option>${c}</option>`).join('')}</select>
        </div>
      </div>
      <button class="btn-primary" onclick="addGasto()">Registrar +</button>
    </div>
    ${orcamento>0?`
    <div class="card" style="animation-delay:.05s">
      <div class="stat-row">
        <div><div class="stat-lbl">Total gasto</div><div class="stat-val green">${v.moeda} ${totalGasto.toFixed(2)}</div></div>
        <div style="text-align:right"><div class="stat-lbl">Orçamento</div><div class="stat-val muted">${v.moeda} ${orcamento}</div></div>
      </div>
      <div class="progress-wrap"><div class="progress-fill ${gastoPct>85?'progress-red':'progress-green'}" style="width:${gastoPct}%"></div></div>
      <div class="prog-info"><span class="hg">${gastoPct.toFixed(0)}%</span><span>Sobra ${v.moeda} ${Math.max(orcamento-totalGasto,0).toFixed(2)}</span></div>
    </div>`:''}
    <div class="card" style="animation-delay:.1s">
      <div class="sec-title">🧾 Histórico</div>
      <div id="gastosLista">
        ${lista.length===0?`<div class="empty-state"><div class="empty-icon">🧾</div><div class="empty-h">Nenhum gasto ainda</div></div>`:''}
      </div>
    </div>`;

  const gastosEl = document.getElementById('gastosLista');
  lista.forEach(g => {
    const div=document.createElement('div');div.className='gasto-item';
    const color=CAT_COLORS[g.categoria]||'#8b95b0';
    div.innerHTML=`
      <div class="gasto-icon" style="background:${color}18">${(g.categoria||'📦').split(' ')[0]}</div>
      <div class="gasto-info">
        <div class="gasto-desc">${g.descricao}</div>
        <div class="gasto-meta">${g.categoria||''} · ${new Date(g.created_at).toLocaleDateString('pt-BR')}</div>
      </div>
      <div class="gasto-val">${v.moeda} ${parseFloat(g.valor).toFixed(2)}</div>
      <button class="gasto-del" onclick="delGasto('${g.id}')">✕</button>`;
    gastosEl.appendChild(div);
  });

  document.getElementById('gDesc').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('gVal').focus();});
  document.getElementById('gVal').addEventListener('keydown',e=>{if(e.key==='Enter')addGasto();});
}

async function addGasto() {
  const desc=document.getElementById('gDesc').value.trim();
  const val=document.getElementById('gVal').value;
  const cat=document.getElementById('gCat').value;
  if(!desc||!val)return;
  await supa.from('gastos').insert([{viagem_id:currentViagem.id,user_id:currentUser.id,descricao:desc,valor:parseFloat(val),categoria:cat}]);
  renderTab('gastos');
}

async function delGasto(id) {
  await supa.from('gastos').delete().eq('id',id);
  renderTab('gastos');
}

// ── MALA ──
async function renderMala(el) {
  const v = currentViagem;
  const { data: malaData } = await supa.from('mala').select('*').eq('viagem_id', v.id);
  const malaMap = {};
  (malaData||[]).forEach(m => malaMap[m.item_key] = m.id);
  
  const allItems = Object.values(MALA_GROUPS).flat();
  const packed = allItems.filter(i => {
    const g = Object.keys(MALA_GROUPS).find(g => MALA_GROUPS[g].includes(i));
    return !!malaMap[`${g}|${i}`];
  }).length;
  const malaPct = Math.round((packed/allItems.length)*100);

  el.innerHTML = `
    <div class="card">
      <div class="sec-title">🎒 Lista de Mala</div>
      <div style="display:flex;justify-content:space-between;margin-bottom:10px">
        <span style="font-size:12px;color:#7d8ba8">${packed} / ${allItems.length} itens</span>
        <span style="font-size:12px;font-weight:600;color:${malaPct===100?'#22c55e':'#93b4fd'}">${malaPct}%</span>
      </div>
      <div class="progress-wrap"><div class="progress-fill ${malaPct===100?'progress-green':'progress-blue'}" style="width:${malaPct}%"></div></div>
    </div>`;

  Object.entries(MALA_GROUPS).forEach(([group, items], gi) => {
    const card=document.createElement('div');card.className='card';card.style.animationDelay=`${gi*.05}s`;
    card.innerHTML=`<div class="sec-title">${group}</div><div id="mg-${gi}"></div>`;
    el.appendChild(card);
    const container=card.querySelector(`#mg-${gi}`);
    items.forEach(item=>{
      const key=`${group}|${item}`;
      const isPacked=!!malaMap[key];
      const div=document.createElement('div');
      div.className=`mala-item${isPacked?' packed':''}`;
      div.innerHTML=`<div class="mala-chk">${isPacked?'✓':''}</div><span>${item}</span>`;
      div.addEventListener('click',async()=>{
        if(malaMap[key]){
          await supa.from('mala').delete().eq('id',malaMap[key]);
          delete malaMap[key];
        } else {
          const {data}=await supa.from('mala').insert([{viagem_id:v.id,user_id:currentUser.id,item_key:key,packed:true}]).select().single();
          if(data)malaMap[key]=data.id;
        }
        div.classList.toggle('packed');
        const chk=div.querySelector('.mala-chk');
        const isNowPacked=div.classList.contains('packed');
        chk.textContent=isNowPacked?'✓':'';
        chk.style.background=isNowPacked?'#22c55e':'';
        chk.style.borderColor=isNowPacked?'#22c55e':'';
        chk.style.color=isNowPacked?'#fff':'';
      });
      container.appendChild(div);
    });
  });
}

// ── IA ──
const IA_SYSTEM = `Você é o assistente de viagens do app "Acima das Nuvens". Slogan: "Só quem se arrisca merece viver o extraordinário". Especialista em viagens pela América Latina.
Quando tiver destino + duração + orçamento, retorne APENAS JSON puro:
{"roteiro":{"destino":"Cidade, País","emoji":"🌍","datas":"Período","dias":7,"orcamento_total":"$700","dias_roteiro":[{"dia":1,"data":"10/07 · Seg","titulo":"Chegada","atividades":[{"horario":"15:00","titulo":"Nome","descricao":"Descrição rica","tipo":"transport","custo":"~$10"}]}],"resumo_financeiro":[{"item":"Hospedagem","valor":"~$70"},{"item":"TOTAL","valor":"~$246"}],"dicas":["Dica 1","Dica 2","Dica 3"]}}
Tipos: transport, tour, food, hotel, free. Faça UMA pergunta por vez se faltar info.`;

function renderIA(el) {
  el.innerHTML=`<div class="ia-wrap">
    <div class="ia-msgs" id="iaMsgs"></div>
    <div class="ia-input-row">
      <textarea id="iaInput" class="ia-textarea" placeholder="Pergunte sobre sua viagem ou peça um roteiro..." rows="1" onkeydown="iaKey(event)" oninput="iaResize(this)"></textarea>
      <button class="ia-send" id="iaSend" onclick="iaSend()">➤</button>
    </div>
  </div>`;
  if(iaHistory.length===0){
    addIaMsg('ai',`Olá! Sou seu assistente ✈️<br>Você está planejando ir para <strong>${currentViagem?.destino||'seu destino'}</strong>.<br><br>Posso montar um roteiro completo ou responder dúvidas. Me conta: quanto tempo você tem e o que curte fazer? 🌍`);
  } else {
    iaHistory.forEach(m=>addIaMsg(m.role==='user'?'user':'ai',m.content.replace(/\n/g,'<br>')));
  }
}

function addIaMsg(role,html){
  const c=document.getElementById('iaMsgs');if(!c)return;
  const w=document.createElement('div');w.className=`ia-msg ${role==='user'?'u':'ai'}`;
  const av=document.createElement('div');av.className='ia-av';av.textContent=role==='user'?'EU':'✦';
  const b=document.createElement('div');b.className='ia-bbl';b.innerHTML=html;
  w.appendChild(av);w.appendChild(b);c.appendChild(w);c.scrollTop=c.scrollHeight;
}

function iaResize(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,90)+'px';}
function iaKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();iaSend();}}

async function iaSend(){
  if(iaBusy)return;
  const inp=document.getElementById('iaInput'),txt=inp.value.trim();if(!txt)return;
  inp.value='';inp.style.height='auto';
  document.getElementById('iaSend').disabled=true;iaBusy=true;
  addIaMsg('user',txt.replace(/\n/g,'<br>'));
  iaHistory.push({role:'user',content:txt});
  const c=document.getElementById('iaMsgs');
  const tw=document.createElement('div');tw.className='ia-msg ai';tw.id='iaTyping';
  const tav=document.createElement('div');tav.className='ia-av';tav.textContent='✦';
  tav.style.cssText='background:linear-gradient(135deg,#4169e1,#6c3aed);color:#fff;font-size:13px;box-shadow:0 0 12px rgba(65,105,225,.4)';
  const tb=document.createElement('div');tb.className='ia-typing';
  tb.innerHTML='<div class="ia-dot"></div><div class="ia-dot"></div><div class="ia-dot"></div>';
  tw.appendChild(tav);tw.appendChild(tb);c.appendChild(tw);c.scrollTop=c.scrollHeight;
  try{
    const res=await fetch('https://api.anthropic.com/v1/messages',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:4096,system:IA_SYSTEM+`\nDestino atual: ${currentViagem?.destino||''}`,messages:iaHistory})
    });
    const data=await res.json(),reply=data.content?.[0]?.text||'';
    document.getElementById('iaTyping')?.remove();
    iaHistory.push({role:'assistant',content:reply});
    let parsed=null;
    try{const m=reply.match(/\{[\s\S]*\}/);if(m)parsed=JSON.parse(m[0]);}catch(e){}
    if(parsed?.roteiro){
      addIaMsg('ai',`Prontinho! 🎉 Roteiro para <strong>${parsed.roteiro.destino}</strong>:`);
      renderRoteiroCard(parsed.roteiro);
    } else {addIaMsg('ai',reply.replace(/\n/g,'<br>'));}
  }catch(e){document.getElementById('iaTyping')?.remove();addIaMsg('ai','Erro de conexão. Tente novamente! 🔄');}
  document.getElementById('iaSend').disabled=false;iaBusy=false;
}

function renderRoteiroCard(r){
  const c=document.getElementById('iaMsgs');
  const wrap=document.createElement('div');wrap.style.cssText='animation:fadeUp .4s ease both;max-width:100%';
  const days=r.dias_roteiro.map((d,i)=>`
    <div class="dia-block" style="animation-delay:${i*.06}s">
      <div class="dia-header"><span class="dia-badge">dia ${d.dia}</span><span class="dia-title">${d.titulo}</span><span class="dia-date">${d.data}</span></div>
      ${d.atividades.map(a=>{const[cls,lbl]=TAG_MAP[a.tipo]||['tag-l','✨ livre'];
        return`<div class="ativ-row"><div class="ativ-time">${a.horario}</div><div class="ativ-body"><div class="ativ-title">${a.titulo}<span class="ativ-tag ${cls}">${lbl}</span></div><div class="ativ-desc">${a.descricao}</div></div>${a.custo?`<div class="ativ-cost">${a.custo}</div>`:''}</div>`;
      }).join('')}
    </div>`).join('');
  wrap.innerHTML=`
    <div class="roteiro-hero" style="margin:0 0 14px"><div class="roteiro-dest">${r.emoji} ${r.destino}</div><div class="roteiro-dates">${r.datas}</div>
    <div class="roteiro-pills"><div class="roteiro-pill"><span class="roteiro-pill-v">${r.dias}</span><span class="roteiro-pill-l">dias</span></div><div class="roteiro-pill"><span class="roteiro-pill-v">${r.orcamento_total}</span><span class="roteiro-pill-l">orçamento</span></div></div></div>
    ${days}
    <div class="card" style="margin:0 0 12px"><div class="sec-title">💵 Resumo</div>${r.resumo_financeiro.map(b=>`<div class="budget-row"><span>${b.item}</span><span>${b.valor}</span></div>`).join('')}</div>
    ${r.dicas?.length?`<div class="tips-block" style="margin-bottom:12px"><div class="tips-title">✦ dicas</div>${r.dicas.map(d=>`<div class="tip-item">${d}</div>`).join('')}</div>`:''}`;
  c.appendChild(wrap);c.scrollTop=c.scrollHeight;
}

// ── INIT ──
initAuth();
